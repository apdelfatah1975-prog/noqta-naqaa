import React, { useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, Camera, CheckCircle2, Clock3, MapPin, Mic, ShieldCheck, Square, UserRound, Wifi, Wrench } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { queueOfflineWorkOrderProof, queueOfflineWorkOrderUpdate } from "@/lib/offlineSync";
import { CustomerContactActions } from "@/components/CustomerContactActions";

const statusLabels: Record<string, string> = {
  assigned: "مسند",
  en_route: "في الطريق",
  arrived: "وصل",
  in_progress: "قيد التنفيذ",
  completed: "مكتمل",
  postponed: "مؤجل",
  cancelled: "ملغى",
};

const serviceLabels: Record<string, string> = {
  installation: "تركيب فلتر",
  maintenance: "صيانة",
  cartridge_change: "تغيير شمعات",
  follow_up: "متابعة",
  other: "أخرى",
};

type SelectedItem = { inventoryItemId: number; quantity: number; source: "manual" };
const MAX_COLLECTION_AMOUNT = 100000;
const resultQuickChoices = ["تم التركيب بنجاح", "تمت الصيانة", "تم تغيير الشمعات", "تم الفحص والمتابعة", "يحتاج قطعة غيار", "يحتاج زيارة متابعة"];
const notCompletedQuickChoices = ["العميل غير موجود", "العميل طلب التأجيل", "تعذر الوصول للموقع", "الموقع مغلق", "تحتاج الزيارة موافقة الإدارة", "سبب آخر"];
const collectionQuickChoices = ["0", "50", "100", "250", "500", "1000"];

export default function TechnicianPreview() {
  const [, setLocation] = useLocation();
  const { user, logout } = useAuth();
  const [filter, setFilter] = useState("all");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [result, setResult] = useState("");
  const [outcome, setOutcome] = useState<"completed" | "not_completed">("completed");
  const [notCompletedReason, setNotCompletedReason] = useState("");
  const [proofDataUrl, setProofDataUrl] = useState<string | null>(null);
  const [proofName, setProofName] = useState("");
  const [audioDataUrl, setAudioDataUrl] = useState<string | null>(null);
  const [audioName, setAudioName] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const [amount, setAmount] = useState("");
  const [collectionState, setCollectionState] = useState<"paid" | "partial" | "unpaid">("paid");
  const [online, setOnline] = useState(() => typeof navigator === "undefined" || navigator.onLine);
  const [localUpdates, setLocalUpdates] = useState<Record<number, { status: string; visitResult?: string | null; collectedAmount?: number }>>({});
  useEffect(() => {
    const goOnline = () => setOnline(true);
    const goOffline = () => setOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => { window.removeEventListener("online", goOnline); window.removeEventListener("offline", goOffline); };
  }, []);
  const query = trpc.filters.workOrders.list.useQuery(undefined, { retry: false, staleTime: 30_000 });
  const utils = trpc.useUtils();
  const addProof = trpc.filters.workOrders.addProof.useMutation({
    onSuccess: () => {
      toast.success("تم إرسال مرفق الزيارة للمتابع");
      void query.refetch();
      void utils.filters.workOrders.list.invalidate();
    },
    onError: error => toast.error(error.message || "تعذر إرسال صورة الزيارة"),
  });
  const update = trpc.filters.workOrders.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("تم حفظ تحديث أمر العمل");
      query.refetch();
      utils.filters.visits.list.invalidate();
      utils.filters.dashboard.invalidate();
      setSelectedId(null);
      setResult("");
      setOutcome("completed");
      setNotCompletedReason("");
      setProofDataUrl(null);
      setProofName("");
      setAudioDataUrl(null);
      setAudioName("");
      setIsRecording(false);
      setAmount("");
      setCollectionState("paid");
    },
    onError: error => toast.error(error.message || "تعذر حفظ التحديث"),
  });

  const orders = useMemo(() => (query.data ?? []).map(order => localUpdates[order.id] ? { ...order, ...localUpdates[order.id] } : order), [localUpdates, query.data]);
  const visible = useMemo(() => filter === "all" ? orders : orders.filter(order => order.status === filter), [filter, orders]);
  const selected = orders.find(order => order.id === selectedId);

  const startRecording = async () => {
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      toast.error("المتصفح لا يدعم تسجيل الصوت؛ استخدم الكتابة اليدوية.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const preferredMime = ["audio/webm;codecs=opus", "audio/webm", "audio/ogg"].find(type => MediaRecorder.isTypeSupported(type));
      const recorder = new MediaRecorder(stream, preferredMime ? { mimeType: preferredMime } : undefined);
      audioChunksRef.current = [];
      recorder.ondataavailable = event => { if (event.data.size > 0) audioChunksRef.current.push(event.data); };
      recorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: recorder.mimeType || "audio/webm" });
        if (blob.size > 10 * 1024 * 1024) {
          toast.error("حجم التسجيل الصوتي أكبر من 10 ميجابايت.");
        } else {
          const reader = new FileReader();
          reader.onload = () => { if (typeof reader.result === "string") { setAudioDataUrl(reader.result); setAudioName("تسجيل صوتي"); } };
          reader.readAsDataURL(blob);
          toast.success("تم تجهيز التسجيل الصوتي");
        }
        stream.getTracks().forEach(track => track.stop());
        setIsRecording(false);
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecording(true);
      toast.success("بدأ التسجيل؛ اضغط مرة أخرى عند الانتهاء");
    } catch {
      toast.error("تعذر الوصول إلى الميكروفون؛ اسمح بالوصول أو استخدم الكتابة.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current?.state === "recording") mediaRecorderRef.current.stop();
  };

  const addQuickResult = (choice: string) => {
    setResult(current => current.trim() ? `${current.trim()} — ${choice}` : choice);
  };

  const saveUpdate = (input: { id: number; status: "en_route" | "arrived" | "in_progress" | "completed" | "postponed"; visitResult: string | null; notes: string | null; executionOutcome?: "completed" | "not_completed" | null; notCompletedReason?: string | null; collectedAmount: number; items: SelectedItem[] }) => {
    if (!online && user) {
      if (input.executionOutcome === "not_completed" && proofDataUrl) {
        queueOfflineWorkOrderProof(user.id, { visitId: input.id, kind: "photo", dataUrl: proofDataUrl });
      }
      if (audioDataUrl) queueOfflineWorkOrderProof(user.id, { visitId: input.id, kind: "audio", dataUrl: audioDataUrl });
      queueOfflineWorkOrderUpdate(user.id, input);
      setLocalUpdates(current => ({ ...current, [input.id]: { status: input.status, visitResult: input.visitResult, collectedAmount: input.collectedAmount } }));
      toast.success("تم الحفظ على الهاتف، وستتم المزامنة عند عودة الإنترنت");
      setSelectedId(null);
      setResult("");
      setOutcome("completed");
      setNotCompletedReason("");
      setAudioDataUrl(null);
      setAudioName("");
      setIsRecording(false);
      setAmount("");
      setCollectionState("paid");
      return;
    }
    update.mutate(input);
    if (input.executionOutcome === "not_completed" && proofDataUrl) {
      addProof.mutate({ visitId: input.id, kind: "photo", dataUrl: proofDataUrl });
    }
    if (audioDataUrl) addProof.mutate({ visitId: input.id, kind: "audio", dataUrl: audioDataUrl });
  };
  const updateOrder = (id: number, status: "en_route" | "arrived" | "in_progress") => {
    saveUpdate({ id, status, visitResult: null, notes: null, executionOutcome: null, notCompletedReason: null, collectedAmount: 0, items: [] });
  };

  const completeOrder = () => {
    if (!selected) return;
    const normalizedAmount = Number(amount.trim() || "0");
    if (!Number.isFinite(normalizedAmount) || !Number.isInteger(normalizedAmount) || normalizedAmount < 0) {
      toast.error("أدخل مبلغًا صحيحًا غير سالب.");
      return;
    }
    if (normalizedAmount > MAX_COLLECTION_AMOUNT) {
      toast.error("مبلغ التحصيل غير منطقي؛ الحد الأقصى المسموح 100,000.");
      return;
    }
    const items: SelectedItem[] = [];
    if (outcome === "not_completed" && !notCompletedReason.trim()) {
      toast.error("اكتب سبب عدم تنفيذ الزيارة قبل الحفظ.");
      return;
    }
    saveUpdate({
      id: selected.id,
      status: outcome === "completed" ? "completed" : "postponed",
      executionOutcome: outcome,
      notCompletedReason: outcome === "not_completed" ? notCompletedReason.trim() : null,
      visitResult: result.trim() || (outcome === "completed" ? "تم تنفيذ الخدمة" : "لم يتم تنفيذ الزيارة"),
      notes: null,
      // المبلغ موحّد كوحدة نقدية كاملة في الواجهة والخادم والخزينة.
      collectedAmount: outcome === "completed" ? normalizedAmount : 0,
      items: outcome === "completed" ? items : [],
    });
  };

  return (
    <main dir="rtl" className="mx-auto min-h-screen max-w-xl space-y-3 bg-[#f4faf9] px-3 pb-6 pt-3 sm:px-4">
      <section className="overflow-hidden rounded-[1.5rem] bg-[linear-gradient(135deg,#075e59,#0f766e)] p-4 text-white shadow-lg sm:p-5">
        <div className="flex items-center justify-between gap-3">
          <button type="button" onClick={() => { void logout(); setLocation("/technician-login"); }} className="grid h-10 w-10 place-items-center rounded-xl bg-white/15" aria-label="تسجيل الخروج"><ArrowLeft className="h-5 w-5" /></button>
          <div className="text-left"><p className="text-xs font-bold text-teal-100">حساب الفني</p><h1 className="mt-1 text-2xl font-black">أوامري فقط</h1></div>
          <Wrench className="h-7 w-7 text-teal-100" />
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-white/10 px-3 py-2.5 text-sm"><span className="font-bold">الفني: {user?.name || "حساب الفني"}</span><div className="flex items-center gap-2"><span className="flex items-center gap-1.5 text-teal-50"><Wifi className="h-4 w-4" /> {online ? "متصل ومزامن" : "محفوظ على الهاتف"}</span><Button type="button" onClick={() => setLocation("/technician-pending-operations")} variant="secondary" size="sm" className="h-8 rounded-lg bg-white text-teal-800 hover:bg-teal-50">العمليات المعلقة</Button></div></div>
      </section>

      <section className="grid grid-cols-3 gap-2">
        {[{ key: "all", label: "كل الأوامر", value: orders.length }, { key: "in_progress", label: "قيد التنفيذ", value: orders.filter(order => ["en_route", "arrived", "in_progress"].includes(order.status)).length }, { key: "completed", label: "مكتملة", value: orders.filter(order => order.status === "completed").length }].map(stat => <button key={stat.key} type="button" onClick={() => setFilter(stat.key)} className={`rounded-xl border bg-white p-2.5 text-center shadow-sm ${filter === stat.key ? "border-teal-500 ring-2 ring-teal-100" : "border-slate-200"}`}><p className="text-[11px] font-bold text-slate-500">{stat.label}</p><p className="mt-1 text-2xl font-black text-teal-800">{stat.value}</p></button>)}
      </section>

      <section className="rounded-2xl border border-emerald-100 bg-emerald-50 p-3.5"><div className="flex items-start gap-3"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-emerald-600 text-white"><ShieldCheck className="h-5 w-5" /></div><div><h2 className="font-black text-emerald-950">أوامرك المسندة فقط</h2><p className="mt-1 text-xs font-semibold leading-6 text-emerald-800">تظهر هنا أوامر العمل الخاصة بك فقط، دون الخزينة أو التقارير أو بيانات باقي الفنيين.</p></div></div></section>

      <section className="space-y-2.5"><div className="flex items-center justify-between"><div><h2 className="text-lg font-black text-slate-900">أوامر الشغل</h2><p className="mt-1 text-xs font-bold text-slate-500">حدّث الحالة بعد كل خطوة</p></div><span className="rounded-full bg-teal-100 px-3 py-1 text-xs font-black text-teal-800">{visible.length} أوامر</span></div>
        {visible.length ? visible.map(order => <article key={order.id} className="rounded-2xl border border-slate-200 bg-white p-3.5 shadow-sm"><div className="flex items-start gap-3"><div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-teal-50 text-teal-700"><UserRound className="h-6 w-6" /></div><div className="min-w-0 flex-1"><div className="flex items-start justify-between gap-2"><div><h3 className="truncate text-base font-black text-slate-900">{order.customer?.name || "عميل"}</h3><p className="mt-1 text-xs font-bold text-slate-500">{serviceLabels[order.visitType] || order.visitType}</p></div><span className="shrink-0 rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-black text-slate-700">{statusLabels[order.status] || order.status}</span></div><div className="mt-3 space-y-2 text-xs font-bold text-slate-500"><span className="flex items-center gap-1.5"><Clock3 className="h-4 w-4 text-teal-600" />{new Date(order.visitDate).toLocaleString("ar-EG", { dateStyle: "medium", timeStyle: "short" })}</span><span className="flex items-start gap-1.5"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-teal-600" />{order.customer?.address || "العنوان غير مسجل"}</span></div></div></div><div className="mt-4 flex flex-wrap items-center gap-2"><CustomerContactActions customer={order.customer ?? {}} compact labels className="shrink-0" />{order.status === "assigned" ? <Button type="button" onClick={() => updateOrder(order.id, "en_route")} className="h-10 rounded-xl bg-teal-700 text-xs font-black">في الطريق</Button> : order.status !== "completed" && order.status !== "cancelled" ? <Button type="button" onClick={() => { setSelectedId(order.id); setResult(order.visitResult || ""); setOutcome(order.executionOutcome === "not_completed" ? "not_completed" : "completed"); setNotCompletedReason(order.notCompletedReason || ""); setProofDataUrl(null); setProofName("");       setAudioDataUrl(null); setAudioName(""); setIsRecording(false); setCollectionState("paid"); }} aria-label="تحديث" className="h-10 rounded-xl bg-teal-700 text-xs font-black">تحديث / تسجيل التنفيذ</Button> : <span className="flex h-10 items-center justify-center rounded-xl bg-emerald-50 text-xs font-black text-emerald-800">تم الحفظ</span>}</div>{order.status === "en_route" ? <Button type="button" onClick={() => updateOrder(order.id, "arrived")} className="mt-2 h-10 w-full rounded-xl bg-sky-700 text-xs font-black">وصلت إلى العميل</Button> : null}{order.status === "arrived" ? <Button type="button" onClick={() => updateOrder(order.id, "in_progress")} className="mt-2 h-10 w-full rounded-xl bg-indigo-700 text-xs font-black">بدء التنفيذ</Button> : null}</article>) : <div className="rounded-3xl border border-dashed border-slate-300 bg-white p-8 text-center text-sm font-bold text-slate-500">لا توجد أوامر مسندة حاليًا.</div>}
      </section>

      {selected ? (
        <section className="rounded-3xl border border-teal-200 bg-white p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-teal-700">إغلاق أمر العمل</p>
              <h2 className="mt-1 text-lg font-black text-slate-900">{selected.customer?.name}</h2>
            </div>
            <button type="button" onClick={() => setSelectedId(null)} className="text-sm font-black text-slate-500">إغلاق</button>
          </div>
          <div className="mt-4">
            <p className="text-sm font-black text-slate-700">نتيجة الزيارة</p>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <button type="button" onClick={() => setOutcome("completed")} className={`rounded-xl border p-3 text-sm font-black ${outcome === "completed" ? "border-emerald-500 bg-emerald-50 text-emerald-800 ring-2 ring-emerald-100" : "border-slate-200 bg-white text-slate-600"}`}>تم التنفيذ</button>
              <button type="button" onClick={() => setOutcome("not_completed")} className={`rounded-xl border p-3 text-sm font-black ${outcome === "not_completed" ? "border-amber-500 bg-amber-50 text-amber-800 ring-2 ring-amber-100" : "border-slate-200 bg-white text-slate-600"}`}>لم يتم التنفيذ</button>
            </div>
            {outcome === "not_completed" ? <><div className="mt-3"><p className="text-sm font-black text-amber-900">اختر سبب عدم التنفيذ</p><div className="mt-2 flex flex-wrap gap-2">{notCompletedQuickChoices.map(choice => <button key={choice} type="button" onClick={() => setNotCompletedReason(choice)} className={`rounded-full border px-3 py-2 text-xs font-black ${notCompletedReason === choice ? "border-amber-500 bg-amber-100 text-amber-900" : "border-amber-200 bg-white text-amber-800"}`}>{choice}</button>)}</div></div><label className="mt-3 block text-sm font-black text-amber-900">تفاصيل إضافية<textarea aria-label="سبب عدم التنفيذ" value={notCompletedReason} onChange={event => setNotCompletedReason(event.target.value)} className="mt-2 min-h-20 w-full rounded-xl border border-amber-200 bg-amber-50/40 p-3 font-bold" placeholder="اختر سببًا أو اكتب تفاصيل إضافية" /></label><label className="mt-3 block text-sm font-black text-amber-900"><span className="flex items-center gap-2"><Camera className="h-4 w-4" />صورة الحالة للمتابع (اختياري)</span><input aria-label="صورة الزيارة" type="file" accept="image/jpeg,image/png,image/webp" capture="environment" onChange={event => { const file = event.target.files?.[0]; if (!file) return; if (file.size > 5 * 1024 * 1024) { toast.error("حجم الصورة يجب ألا يتجاوز 5 ميجابايت."); return; } const reader = new FileReader(); reader.onload = () => { if (typeof reader.result === "string") { setProofDataUrl(reader.result); setProofName(file.name); } }; reader.readAsDataURL(file); }} className="mt-2 block w-full rounded-xl border border-amber-200 bg-amber-50/40 p-3 text-sm font-bold" /><span className="mt-1 block text-[11px] font-bold text-slate-500">{proofName ? `تم اختيار: ${proofName}` : "صوّر الحالة من الهاتف ليشاهدها المتابع"}</span>{proofDataUrl ? <img src={proofDataUrl} alt="معاينة صورة الزيارة" className="mt-2 h-32 w-full rounded-xl object-cover" /> : null}</label></> : null}
          </div>
          <div className="mt-4"><p className="text-sm font-black text-slate-700">اختر ما تم تنفيذه</p><div className="mt-2 flex flex-wrap gap-2">{resultQuickChoices.map(choice => <button key={choice} type="button" onClick={() => addQuickResult(choice)} className="rounded-full border border-teal-200 bg-teal-50 px-3 py-2 text-xs font-black text-teal-800">{choice}</button>)}</div></div>
          <label className="mt-3 block text-sm font-black text-slate-700">ملاحظات إضافية<textarea aria-label="ما تم تنفيذه" value={result} onChange={event => setResult(event.target.value)} className="mt-2 min-h-20 w-full rounded-xl border border-slate-200 p-3 font-bold" placeholder="اكتب تفاصيل إضافية أو استخدم التسجيل الصوتي" /></label>
          <div className="mt-3 rounded-2xl border border-teal-100 bg-teal-50/60 p-3">
            <div className="flex items-center justify-between gap-2"><div><p className="text-sm font-black text-teal-950">ملاحظة صوتية اختيارية</p><p className="mt-1 text-[11px] font-bold text-teal-800">يمكنك الكتابة أو التسجيل أو استخدام الاثنين معًا.</p></div><button type="button" onClick={isRecording ? stopRecording : startRecording} className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl text-white ${isRecording ? "bg-rose-600" : "bg-teal-700"}`} aria-label={isRecording ? "إيقاف التسجيل" : "بدء التسجيل"}>{isRecording ? <Square className="h-5 w-5" /> : <Mic className="h-5 w-5" />}</button></div>
            {isRecording ? <p className="mt-2 text-xs font-black text-rose-700">جاري التسجيل… اضغط الزر لإيقافه.</p> : null}
            {audioDataUrl ? <div className="mt-3 flex items-center gap-2"><audio controls src={audioDataUrl} className="h-10 min-w-0 flex-1" /><button type="button" onClick={() => { setAudioDataUrl(null); setAudioName(""); }} className="rounded-lg px-2 py-1 text-xs font-black text-rose-700">حذف</button><span className="sr-only">{audioName}</span></div> : null}
          </div>
          <div className="mt-3"><p className="text-sm font-black text-slate-700">حالة التحصيل</p><div className="mt-2 grid grid-cols-3 gap-2"><button type="button" onClick={() => setCollectionState("paid")} className={`rounded-xl border p-2 text-xs font-black ${collectionState === "paid" ? "border-emerald-500 bg-emerald-50 text-emerald-800" : "border-slate-200 bg-white text-slate-600"}`}>تم التحصيل</button><button type="button" onClick={() => setCollectionState("partial")} className={`rounded-xl border p-2 text-xs font-black ${collectionState === "partial" ? "border-amber-500 bg-amber-50 text-amber-800" : "border-slate-200 bg-white text-slate-600"}`}>جزء من المبلغ</button><button type="button" onClick={() => { setCollectionState("unpaid"); setAmount("0"); }} className={`rounded-xl border p-2 text-xs font-black ${collectionState === "unpaid" ? "border-rose-500 bg-rose-50 text-rose-800" : "border-slate-200 bg-white text-slate-600"}`}>لم يتم التحصيل</button></div></div>
          <label className="mt-3 block text-sm font-black text-slate-700">المبلغ المحصل<input aria-label="المبلغ المحصل" inputMode="numeric" min="0" max={MAX_COLLECTION_AMOUNT} value={amount} onChange={event => { setCollectionState("partial"); setAmount(event.target.value.replace(/[^0-9-]/g, "")); }} className="mt-2 h-12 w-full rounded-xl border border-slate-200 px-3 text-lg font-black" placeholder="0" /><div className="mt-2 flex flex-wrap gap-2">{collectionQuickChoices.map(choice => <button key={choice} type="button" onClick={() => { setCollectionState(choice === "0" ? "unpaid" : "partial"); setAmount(choice); }} className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-black text-slate-700">{choice}</button>)}</div><span className="mt-1 block text-[11px] font-bold text-slate-500">اختر مبلغًا سريعًا أو اكتب الرقم كما هو</span></label>
          <Button type="button" onClick={completeOrder} disabled={update.isPending} className="mt-4 h-12 w-full rounded-xl bg-teal-700 font-black hover:bg-teal-800">{update.isPending ? "جاري الحفظ..." : <><CheckCircle2 className="ml-2 h-5 w-5" /> حفظ وإغلاق أمر العمل</>}</Button>
        </section>
      ) : null}
    </main>
  );
}
